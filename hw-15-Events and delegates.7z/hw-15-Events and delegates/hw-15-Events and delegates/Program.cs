﻿using System.Timers;

class Tamagotchi
{
    private System.Timers.Timer timer;
    private int health = 100;
    private int unfulfilledRequests = 0;
    private string[] requests = { "feed", "walk", "put to bed", "play" };
    private string lastRequest = string.Empty;
    private Random random = new Random();
    private int remainingTime = 100;

    public event Action<string> Request;
    public event Action<int> HealthChanged;
    public event Action Happy;
    public event Action NoFun;
    public event Action Sad;
    public event Action Sick;
    public event Action GameOver;

    public Tamagotchi()
    {
        timer = new System.Timers.Timer(1000);
        timer.Elapsed += OnTimer;
        timer.Start();
    }

    public void Start()
    {
        Console.WriteLine("Your Tamagotchi has 100 HP");

        while (health > 0 && remainingTime > 0)
        {
            string request = GenerateRequest();
            Request?.Invoke(request);

            if (health == 100 || health == 67)
                Happy?.Invoke();
            else if (health == 34)
                NoFun?.Invoke();
            else if (health == 1)
                Sad?.Invoke();

            bool responseReceived = false;
            DateTime requestTime = DateTime.Now;

            while ((DateTime.Now - requestTime).TotalSeconds < 4 && !responseReceived)
            {
                if ((DateTime.Now - requestTime).TotalSeconds >= 3.9)
                {
                    Console.Clear();
                }


                if (Console.KeyAvailable)
                {
                    string action = Console.ReadLine();
                    Console.Clear();

                    if (action == "1")
                    {
                        health = Math.Min(health + 33, 100);
                        HealthChanged?.Invoke(health);
                        unfulfilledRequests = 0;
                        responseReceived = true;
                    }
                    else
                        break;
                }
            }

            if (!responseReceived)
            {
                unfulfilledRequests++;
                health -= 33;
                if (health < 0) health = 0;
                HealthChanged?.Invoke(health);

                if (unfulfilledRequests == 3)
                {
                    if (health == 1)
                        Sick?.Invoke();
                    else
                    {
                        GameOver?.Invoke();
                        break;
                    }
                }
            }
        }
        timer.Stop();
    }

    private void OnTimer(object sender, ElapsedEventArgs e)
    {
        if (remainingTime > 0) remainingTime--;
        else GameOver?.Invoke();
    }

    private string GenerateRequest()
    {
        string request;
        do
        {
            request = requests[random.Next(requests.Length)];
        } while (request == lastRequest);

        lastRequest = request;
        return request;
    }
}

class TamListener
{
    public void Subscribe(Tamagotchi tamagotchi)
    {
        tamagotchi.Request += HandleRequest;
        tamagotchi.HealthChanged += HandleHealthChanged;
        tamagotchi.Happy += HandleHappy;
        tamagotchi.NoFun += HandleNoFun;
        tamagotchi.Sad += HandleSad;
        tamagotchi.Sick += HandleIsSick;
        tamagotchi.GameOver += HandleGameOver;
    }

    private void HandleRequest(string request)
    {
        Console.WriteLine($"Tamagotchi asks: {request}");
    }
    private void HandleHealthChanged(int health)
    {
        Console.WriteLine($"Health Tamagotchi: {health} HP");
    }
    private void HandleHappy()
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("   ╭━━━━━━━━━━━╮");
        Console.WriteLine("   ┃   ^   ^   ┃");
        Console.WriteLine("   ┃     -     ┃");
        Console.WriteLine("   ┃   \\___/   ┃");
        Console.WriteLine("   ┃━━━━━━━━━━━┃");
        Console.WriteLine("   ┃           ┃");
        Console.WriteLine("   ╰━━━━━━━━━━━╯");
        Console.ForegroundColor = ConsoleColor.White;
    }
    private void HandleNoFun()
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("   ╭━━━━━━━━━━━╮");
        Console.WriteLine("   ┃   o   o   ┃");
        Console.WriteLine("   ┃     -     ┃");
        Console.WriteLine("   ┃     |     ┃");
        Console.WriteLine("   ┃━━━━━━━━━━━┃");
        Console.WriteLine("   ┃           ┃");
        Console.WriteLine("   ╰━━━━━━━━━━━╯");
        Console.ForegroundColor = ConsoleColor.White;
    }
    private void HandleSad()
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("   ╭━━━━━━━━━━━╮");
        Console.WriteLine("   ┃   T   T   ┃");
        Console.WriteLine("   ┃     -     ┃");
        Console.WriteLine("   ┃   \\___/   ┃");
        Console.WriteLine("   ┃━━━━━━━━━━━┃");
        Console.WriteLine("   ┃           ┃");
        Console.WriteLine("   ╰━━━━━━━━━━━╯");
        Console.ForegroundColor = ConsoleColor.White;
    }
    private void HandleIsSick()
    {
        Console.WriteLine("Tamagotchi got sick! He asks to be treated");
    }
    private void HandleGameOver()
    {
        Console.WriteLine("Game over");
    }
}

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        try
        {
            Tamagotchi tam = new();
            TamListener tamlistener = new();
            tamlistener.Subscribe(tam);
            tam.Start();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }
    }
}
